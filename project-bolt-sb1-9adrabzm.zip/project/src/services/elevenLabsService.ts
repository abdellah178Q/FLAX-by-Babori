const API_KEY = 'sk_e62f7a765223f7f493893aeb6e37529396b96d298b0d691c';
const BASE_URL = 'https://api.elevenlabs.io/v1';

export class ElevenLabsService {
  private static headers = {
    'Accept': 'audio/mpeg',
    'Content-Type': 'application/json',
    'xi-api-key': API_KEY
  };

  static async getVoices() {
    try {
      const response = await fetch(`${BASE_URL}/voices`, {
        method: 'GET',
        headers: {
          'xi-api-key': API_KEY
        }
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      return data.voices || [];
    } catch (error) {
      console.error('Error fetching voices:', error);
      return [];
    }
  }

  static async generateSpeech(text: string, voiceId: string, settings: any = {}) {
    try {
      const payload = {
        text,
        model_id: "eleven_multilingual_v2",
        voice_settings: {
          stability: settings.stability || 0.5,
          similarity_boost: settings.similarity_boost || 0.75,
          style: settings.style || 0.0,
          use_speaker_boost: settings.use_speaker_boost || true
        }
      };

      const response = await fetch(`${BASE_URL}/text-to-speech/${voiceId}`, {
        method: 'POST',
        headers: this.headers,
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return response.blob();
    } catch (error) {
      console.error('Error generating speech:', error);
      throw error;
    }
  }

  static async getVoiceSettings(voiceId: string) {
    try {
      const response = await fetch(`${BASE_URL}/voices/${voiceId}/settings`, {
        method: 'GET',
        headers: {
          'xi-api-key': API_KEY
        }
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      return response.json();
    } catch (error) {
      console.error('Error fetching voice settings:', error);
      return null;
    }
  }

  static async getModels() {
    try {
      const response = await fetch(`${BASE_URL}/models`, {
        method: 'GET',
        headers: {
          'xi-api-key': API_KEY
        }
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      return response.json();
    } catch (error) {
      console.error('Error fetching models:', error);
      return [];
    }
  }

  static async createVoice(formData: FormData) {
    try {
      const response = await fetch(`${BASE_URL}/voices/add`, {
        method: 'POST',
        headers: {
          'xi-api-key': API_KEY
        },
        body: formData
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return response.json();
    } catch (error) {
      console.error('Error creating voice:', error);
      throw error;
    }
  }

  static async deleteVoice(voiceId: string) {
    try {
      const response = await fetch(`${BASE_URL}/voices/${voiceId}`, {
        method: 'DELETE',
        headers: {
          'xi-api-key': API_KEY
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return response.json();
    } catch (error) {
      console.error('Error deleting voice:', error);
      throw error;
    }
  }

  static async getUser() {
    try {
      const response = await fetch(`${BASE_URL}/user`, {
        method: 'GET',
        headers: {
          'xi-api-key': API_KEY
        }
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      return response.json();
    } catch (error) {
      console.error('Error fetching user info:', error);
      return null;
    }
  }

  static async getUsage() {
    try {
      const response = await fetch(`${BASE_URL}/user/subscription`, {
        method: 'GET',
        headers: {
          'xi-api-key': API_KEY
        }
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      return response.json();
    } catch (error) {
      console.error('Error fetching usage info:', error);
      return null;
    }
  }
}
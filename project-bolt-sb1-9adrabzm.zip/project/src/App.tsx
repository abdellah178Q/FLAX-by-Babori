import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { TextInput } from './components/TextInput';
import { VoiceSelector } from './components/VoiceSelector';
import { AudioControls } from './components/AudioControls';
import { Settings } from './components/Settings';
import { VoiceCloning } from './components/VoiceCloning';
import { BatchProcessor } from './components/BatchProcessor';
import { AdvancedSettings } from './components/AdvancedSettings';
import { useAudio } from './hooks/useAudio';
import { ElevenLabsService } from './services/elevenLabsService';
import { downloadAudio } from './utils/fileUtils';
import { Voice, AppSettings } from './types';

function App() {
  const [text, setText] = useState('');
  const [selectedVoice, setSelectedVoice] = useState<Voice | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showVoiceCloning, setShowVoiceCloning] = useState(false);
  const [showBatchProcessor, setShowBatchProcessor] = useState(false);
  const [showAdvancedSettings, setShowAdvancedSettings] = useState(false);
  const [currentAudioBlob, setCurrentAudioBlob] = useState<Blob | null>(null);
  const [volume, setVolume] = useState(0.8);
  const [playbackSpeed, setPlaybackSpeed] = useState(1.0);
  
  const [voiceSettings, setVoiceSettings] = useState({
    stability: 0.5,
    similarity_boost: 0.75,
    style: 0.0,
    use_speaker_boost: true
  });

  const [appSettings, setAppSettings] = useState<AppSettings>({
    theme: {
      mode: 'light',
      accessibility: {
        highContrast: false,
        largeText: false,
        dyslexiaFriendly: false
      }
    },
    defaultVoice: '',
    autoPlay: true,
    highlightText: true,
    speechRate: 1.0,
    volume: 0.8
  });

  const {
    audioState,
    loadAudio,
    play,
    pause,
    stop,
    seek,
    setVolume: setAudioVolume,
    setPlaybackRate
  } = useAudio();

  // Apply theme settings
  useEffect(() => {
    const root = document.documentElement;
    if (appSettings.theme.mode === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }

    if (appSettings.theme.accessibility.largeText) {
      root.classList.add('text-lg');
    } else {
      root.classList.remove('text-lg');
    }

    if (appSettings.theme.accessibility.dyslexiaFriendly) {
      root.style.fontFamily = 'OpenDyslexic, sans-serif';
    } else {
      root.style.fontFamily = '';
    }
  }, [appSettings.theme]);

  // Update audio settings when app settings change
  useEffect(() => {
    setVolume(appSettings.volume);
    setPlaybackSpeed(appSettings.speechRate);
  }, [appSettings.volume, appSettings.speechRate]);

  // Update audio volume and playback rate
  useEffect(() => {
    setAudioVolume(volume);
  }, [volume, setAudioVolume]);

  useEffect(() => {
    setPlaybackRate(playbackSpeed);
  }, [playbackSpeed, setPlaybackRate]);

  const handleGenerateSpeech = async () => {
    if (!text.trim() || !selectedVoice) return;

    setIsGenerating(true);
    try {
      const audioBlob = await ElevenLabsService.generateSpeech(
        text,
        selectedVoice.voice_id,
        voiceSettings
      );
      
      setCurrentAudioBlob(audioBlob);
      loadAudio(audioBlob);
      
      if (appSettings.autoPlay) {
        setTimeout(() => play(), 500);
      }
    } catch (error) {
      console.error('Failed to generate speech:', error);
      alert('Failed to generate speech. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownload = () => {
    if (currentAudioBlob) {
      const timestamp = new Date().toISOString().slice(0, 16).replace(/[:.]/g, '-');
      const filename = `flax-speech-${timestamp}.mp3`;
      downloadAudio(currentAudioBlob, filename);
    }
  };

  const handleVoiceSelect = (voice: Voice) => {
    setSelectedVoice(voice);
    if (!appSettings.defaultVoice) {
      setAppSettings(prev => ({
        ...prev,
        defaultVoice: voice.voice_id
      }));
    }
  };

  const handleVoiceCreated = (voiceId: string, voiceName: string) => {
    // In a real implementation, you would refresh the voice list
    // and potentially select the new voice
    console.log('Voice created:', voiceId, voiceName);
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      appSettings.theme.mode === 'dark' 
        ? 'bg-gray-900' 
        : appSettings.theme.accessibility.highContrast 
          ? 'bg-white' 
          : 'bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100'
    }`}>
      <Header
        darkMode={appSettings.theme.mode === 'dark'}
        toggleDarkMode={() => setAppSettings(prev => ({
          ...prev,
          theme: {
            ...prev.theme,
            mode: prev.theme.mode === 'dark' ? 'light' : 'dark'
          }
        }))}
        onSettingsClick={() => setShowSettings(true)}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left Column */}
          <div className="space-y-8">
            <TextInput
              text={text}
              setText={setText}
              onGenerate={handleGenerateSpeech}
              isGenerating={isGenerating}
            />
            
            <VoiceSelector
              selectedVoice={selectedVoice}
              onVoiceSelect={handleVoiceSelect}
              voiceSettings={voiceSettings}
              onSettingsChange={setVoiceSettings}
            />
          </div>

          {/* Right Column */}
          <div className="space-y-8">
            <AudioControls
              audioState={audioState}
              onPlay={play}
              onPause={pause}
              onStop={stop}
              onSeek={seek}
              onVolumeChange={setVolume}
              onSpeedChange={setPlaybackSpeed}
              onDownload={handleDownload}
              volume={volume}
              playbackSpeed={playbackSpeed}
            />

            {/* Advanced Features */}
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-6 transition-colors duration-300">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                Advanced Features
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  onClick={() => setShowVoiceCloning(true)}
                  className="flex items-center justify-center px-4 py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-lg font-medium transition-all duration-300 transform hover:scale-105"
                >
                  Voice Cloning
                </button>
                
                <button
                  onClick={() => setShowBatchProcessor(true)}
                  className="flex items-center justify-center px-4 py-3 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white rounded-lg font-medium transition-all duration-300 transform hover:scale-105"
                >
                  Batch Process
                </button>
                
                <button
                  onClick={() => setShowAdvancedSettings(true)}
                  className="flex items-center justify-center px-4 py-3 bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700 text-white rounded-lg font-medium transition-all duration-300 transform hover:scale-105"
                >
                  Advanced Settings
                </button>
                
                <button
                  disabled
                  className="flex items-center justify-center px-4 py-3 bg-gray-400 text-white rounded-lg font-medium cursor-not-allowed"
                >
                  AI Summarize (Soon)
                </button>
              </div>
            </div>

            {/* Feature Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg">
                <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Multi-Language</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Support for 29+ languages with natural accents and pronunciations.
                </p>
              </div>
              
              <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg">
                <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Voice Cloning</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Create custom voices with advanced AI technology (Premium feature).
                </p>
              </div>
              
              <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg">
                <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Emotion Control</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Adjust voice emotions and style for perfect expression.
                </p>
              </div>
              
              <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg">
                <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Accessibility</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Built for users with visual impairments and reading difficulties.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <footer className="mt-16 text-center text-gray-500 dark:text-gray-400">
          <p className="text-sm">
            FLAX by Babori - Advanced Text-to-Speech Technology
          </p>
          <p className="text-xs mt-1">
            Powered by ElevenLabs AI • Built with ❤️ for accessibility
          </p>
        </footer>
      </main>

      {/* Modals */}
      <Settings
        isOpen={showSettings}
        onClose={() => setShowSettings(false)}
        settings={appSettings}
        onSettingsChange={setAppSettings}
      />

      <VoiceCloning
        isOpen={showVoiceCloning}
        onClose={() => setShowVoiceCloning(false)}
        onVoiceCreated={handleVoiceCreated}
      />

      <BatchProcessor
        isOpen={showBatchProcessor}
        onClose={() => setShowBatchProcessor(false)}
        selectedVoice={selectedVoice}
        voiceSettings={voiceSettings}
      />

      <AdvancedSettings
        isOpen={showAdvancedSettings}
        onClose={() => setShowAdvancedSettings(false)}
        voiceSettings={voiceSettings}
        onSettingsChange={setVoiceSettings}
      />
    </div>
  );
}

export default App;
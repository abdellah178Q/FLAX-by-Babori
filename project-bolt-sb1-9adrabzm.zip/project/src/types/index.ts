export interface Voice {
  voice_id: string;
  name: string;
  preview_url?: string;
  category: 'premade' | 'cloned' | 'professional';
  labels: {
    accent?: string;
    description?: string;
    age?: string;
    gender?: string;
    use_case?: string;
  };
  settings?: {
    stability: number;
    similarity_boost: number;
    style?: number;
    use_speaker_boost?: boolean;
  };
}

export interface SpeechSettings {
  voice_id: string;
  model_id: string;
  voice_settings: {
    stability: number;
    similarity_boost: number;
    style: number;
    use_speaker_boost: boolean;
  };
  pronunciation_dictionary_locators?: any[];
}

export interface AudioState {
  isPlaying: boolean;
  isPaused: boolean;
  currentTime: number;
  duration: number;
  isLoading: boolean;
}

export interface TextContent {
  text: string;
  source: 'manual' | 'file' | 'ocr';
  filename?: string;
  language?: string;
}

export interface Theme {
  mode: 'light' | 'dark';
  accessibility: {
    highContrast: boolean;
    largeText: boolean;
    dyslexiaFriendly: boolean;
  };
}

export interface AppSettings {
  theme: Theme;
  defaultVoice: string;
  autoPlay: boolean;
  highlightText: boolean;
  speechRate: number;
  volume: number;
}
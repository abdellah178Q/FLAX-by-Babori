import { useState, useRef, useEffect } from 'react';
import { AudioState } from '../types';

export const useAudio = () => {
  const [audioState, setAudioState] = useState<AudioState>({
    isPlaying: false,
    isPaused: false,
    currentTime: 0,
    duration: 0,
    isLoading: false
  });

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const loadAudio = (audioBlob: Blob) => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.src = '';
    }

    const audioUrl = URL.createObjectURL(audioBlob);
    audioRef.current = new Audio(audioUrl);
    
    audioRef.current.addEventListener('loadedmetadata', () => {
      setAudioState(prev => ({
        ...prev,
        duration: audioRef.current?.duration || 0,
        isLoading: false
      }));
    });

    audioRef.current.addEventListener('ended', () => {
      setAudioState(prev => ({
        ...prev,
        isPlaying: false,
        isPaused: false,
        currentTime: 0
      }));
      
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    });

    setAudioState(prev => ({ ...prev, isLoading: true }));
  };

  const play = () => {
    if (audioRef.current) {
      audioRef.current.play();
      setAudioState(prev => ({
        ...prev,
        isPlaying: true,
        isPaused: false
      }));

      intervalRef.current = setInterval(() => {
        if (audioRef.current) {
          setAudioState(prev => ({
            ...prev,
            currentTime: audioRef.current?.currentTime || 0
          }));
        }
      }, 100);
    }
  };

  const pause = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      setAudioState(prev => ({
        ...prev,
        isPlaying: false,
        isPaused: true
      }));

      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    }
  };

  const stop = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      setAudioState(prev => ({
        ...prev,
        isPlaying: false,
        isPaused: false,
        currentTime: 0
      }));

      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    }
  };

  const seek = (time: number) => {
    if (audioRef.current) {
      audioRef.current.currentTime = time;
      setAudioState(prev => ({ ...prev, currentTime: time }));
    }
  };

  const setVolume = (volume: number) => {
    if (audioRef.current) {
      audioRef.current.volume = Math.max(0, Math.min(1, volume));
    }
  };

  const setPlaybackRate = (rate: number) => {
    if (audioRef.current) {
      audioRef.current.playbackRate = Math.max(0.25, Math.min(4, rate));
    }
  };

  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
      if (audioRef.current) {
        audioRef.current.pause();
        URL.revokeObjectURL(audioRef.current.src);
      }
    };
  }, []);

  return {
    audioState,
    loadAudio,
    play,
    pause,
    stop,
    seek,
    setVolume,
    setPlaybackRate
  };
};
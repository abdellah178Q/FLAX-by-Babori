import React, { useState, useRef } from 'react';
import { FileText, Upload, Download, Play, Pause, Trash2, Plus, X } from 'lucide-react';
import { ElevenLabsService } from '../services/elevenLabsService';
import { Voice } from '../types';
import { downloadAudio } from '../utils/fileUtils';

interface BatchItem {
  id: string;
  text: string;
  filename: string;
  status: 'pending' | 'processing' | 'completed' | 'error';
  audioBlob?: Blob;
  error?: string;
}

interface BatchProcessorProps {
  isOpen: boolean;
  onClose: () => void;
  selectedVoice: Voice | null;
  voiceSettings: any;
}

export const BatchProcessor: React.FC<BatchProcessorProps> = ({
  isOpen,
  onClose,
  selectedVoice,
  voiceSettings
}) => {
  const [batchItems, setBatchItems] = useState<BatchItem[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentlyPlaying, setCurrentlyPlaying] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);

  if (!isOpen) return null;

  const addTextItem = () => {
    const newItem: BatchItem = {
      id: Date.now().toString(),
      text: '',
      filename: `speech-${batchItems.length + 1}`,
      status: 'pending'
    };
    setBatchItems([...batchItems, newItem]);
  };

  const updateItem = (id: string, updates: Partial<BatchItem>) => {
    setBatchItems(items => 
      items.map(item => 
        item.id === id ? { ...item, ...updates } : item
      )
    );
  };

  const removeItem = (id: string) => {
    setBatchItems(items => items.filter(item => item.id !== id));
  };

  const handleFileUpload = async (files: FileList) => {
    const newItems: BatchItem[] = [];
    
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (file.type.startsWith('text/') || file.name.endsWith('.txt')) {
        try {
          const text = await file.text();
          newItems.push({
            id: Date.now().toString() + i,
            text,
            filename: file.name.replace(/\.[^/.]+$/, ''),
            status: 'pending'
          });
        } catch (error) {
          console.error('Error reading file:', file.name, error);
        }
      }
    }
    
    setBatchItems([...batchItems, ...newItems]);
  };

  const processBatch = async () => {
    if (!selectedVoice) {
      alert('Please select a voice first');
      return;
    }

    setIsProcessing(true);
    
    for (const item of batchItems) {
      if (item.status === 'completed' || !item.text.trim()) continue;
      
      updateItem(item.id, { status: 'processing' });
      
      try {
        const audioBlob = await ElevenLabsService.generateSpeech(
          item.text,
          selectedVoice.voice_id,
          voiceSettings
        );
        
        updateItem(item.id, { 
          status: 'completed', 
          audioBlob 
        });
      } catch (error) {
        updateItem(item.id, { 
          status: 'error', 
          error: 'Failed to generate speech' 
        });
      }
      
      // Small delay between requests to avoid rate limiting
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
    
    setIsProcessing(false);
  };

  const playAudio = (item: BatchItem) => {
    if (!item.audioBlob) return;
    
    if (currentlyPlaying === item.id) {
      audioRef.current?.pause();
      setCurrentlyPlaying(null);
    } else {
      if (audioRef.current) {
        audioRef.current.src = URL.createObjectURL(item.audioBlob);
        audioRef.current.play();
        setCurrentlyPlaying(item.id);
        
        audioRef.current.onended = () => {
          setCurrentlyPlaying(null);
        };
      }
    }
  };

  const downloadItem = (item: BatchItem) => {
    if (item.audioBlob) {
      downloadAudio(item.audioBlob, `${item.filename}.mp3`);
    }
  };

  const downloadAll = () => {
    batchItems
      .filter(item => item.status === 'completed' && item.audioBlob)
      .forEach(item => {
        setTimeout(() => downloadItem(item), 500);
      });
  };

  const completedCount = batchItems.filter(item => item.status === 'completed').length;
  const totalCount = batchItems.length;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
          <div>
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Batch Processor</h2>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Convert multiple texts to speech at once
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors duration-200"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        {/* Controls */}
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex flex-wrap gap-4">
            <button
              onClick={addTextItem}
              className="flex items-center px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors duration-200"
            >
              <Plus className="mr-2 h-4 w-4" />
              Add Text
            </button>
            
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors duration-200"
            >
              <Upload className="mr-2 h-4 w-4" />
              Upload Files
            </button>
            
            <button
              onClick={processBatch}
              disabled={isProcessing || batchItems.length === 0 || !selectedVoice}
              className="flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white rounded-lg transition-colors duration-200"
            >
              {isProcessing ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Processing...
                </>
              ) : (
                <>
                  <Play className="mr-2 h-4 w-4" />
                  Process All
                </>
              )}
            </button>
            
            {completedCount > 0 && (
              <button
                onClick={downloadAll}
                className="flex items-center px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg transition-colors duration-200"
              >
                <Download className="mr-2 h-4 w-4" />
                Download All ({completedCount})
              </button>
            )}
          </div>
          
          {totalCount > 0 && (
            <div className="mt-4">
              <div className="flex justify-between text-sm text-gray-600 dark:text-gray-400 mb-2">
                <span>Progress: {completedCount}/{totalCount}</span>
                <span>{Math.round((completedCount / totalCount) * 100)}%</span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                <div 
                  className="bg-green-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${(completedCount / totalCount) * 100}%` }}
                />
              </div>
            </div>
          )}
        </div>

        {/* Items List */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 max-h-96">
          {batchItems.length === 0 ? (
            <div className="text-center py-12">
              <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500 dark:text-gray-400">
                No items added yet. Add text or upload files to get started.
              </p>
            </div>
          ) : (
            batchItems.map((item) => (
              <div
                key={item.id}
                className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <input
                    type="text"
                    value={item.filename}
                    onChange={(e) => updateItem(item.id, { filename: e.target.value })}
                    className="font-medium bg-transparent border-none focus:outline-none focus:ring-2 focus:ring-purple-500 rounded px-2 py-1"
                    placeholder="Filename"
                  />
                  
                  <div className="flex items-center space-x-2">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      item.status === 'pending' ? 'bg-gray-200 text-gray-700' :
                      item.status === 'processing' ? 'bg-blue-200 text-blue-700' :
                      item.status === 'completed' ? 'bg-green-200 text-green-700' :
                      'bg-red-200 text-red-700'
                    }`}>
                      {item.status}
                    </span>
                    
                    {item.status === 'completed' && item.audioBlob && (
                      <>
                        <button
                          onClick={() => playAudio(item)}
                          className="p-1 rounded hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors duration-200"
                        >
                          {currentlyPlaying === item.id ? (
                            <Pause className="h-4 w-4 text-gray-600" />
                          ) : (
                            <Play className="h-4 w-4 text-gray-600" />
                          )}
                        </button>
                        
                        <button
                          onClick={() => downloadItem(item)}
                          className="p-1 rounded hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors duration-200"
                        >
                          <Download className="h-4 w-4 text-gray-600" />
                        </button>
                      </>
                    )}
                    
                    <button
                      onClick={() => removeItem(item.id)}
                      className="p-1 rounded hover:bg-red-100 dark:hover:bg-red-900 transition-colors duration-200"
                    >
                      <Trash2 className="h-4 w-4 text-red-500" />
                    </button>
                  </div>
                </div>
                
                <textarea
                  value={item.text}
                  onChange={(e) => updateItem(item.id, { text: e.target.value })}
                  placeholder="Enter text to convert to speech..."
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent bg-white dark:bg-gray-800 text-gray-900 dark:text-white resize-none"
                />
                
                {item.error && (
                  <p className="text-sm text-red-600 dark:text-red-400">{item.error}</p>
                )}
              </div>
            ))
          )}
        </div>

        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept=".txt,text/plain"
          className="hidden"
          onChange={(e) => e.target.files && handleFileUpload(e.target.files)}
        />
        
        <audio ref={audioRef} className="hidden" />
      </div>
    </div>
  );
};
import React, { useState, useRef } from 'react';
import { Upload, Mic, MicOff, Play, Pause, Trash2, Save, AlertCircle } from 'lucide-react';

interface VoiceCloningProps {
  isOpen: boolean;
  onClose: () => void;
  onVoiceCreated: (voiceId: string, voiceName: string) => void;
}

export const VoiceCloning: React.FC<VoiceCloningProps> = ({
  isOpen,
  onClose,
  onVoiceCreated
}) => {
  const [isRecording, setIsRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [voiceName, setVoiceName] = useState('');
  const [description, setDescription] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  if (!isOpen) return null;

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      const chunks: BlobPart[] = [];
      mediaRecorder.ondataavailable = (event) => {
        chunks.push(event.data);
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'audio/wav' });
        setAudioBlob(blob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingTime(0);

      intervalRef.current = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
    } catch (error) {
      console.error('Error accessing microphone:', error);
      alert('Could not access microphone. Please check permissions.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    }
  };

  const playRecording = () => {
    if (audioBlob && audioRef.current) {
      audioRef.current.src = URL.createObjectURL(audioBlob);
      audioRef.current.play();
    }
  };

  const clearRecording = () => {
    setAudioBlob(null);
    setRecordingTime(0);
  };

  const createVoice = async () => {
    if (!audioBlob || !voiceName.trim()) {
      alert('Please provide a voice name and recording.');
      return;
    }

    setIsCreating(true);
    try {
      const formData = new FormData();
      formData.append('name', voiceName);
      formData.append('description', description);
      formData.append('files', audioBlob, 'voice-sample.wav');

      // This would be your actual ElevenLabs voice cloning API call
      // const response = await ElevenLabsService.createVoice(formData);
      
      // For demo purposes, simulate success
      setTimeout(() => {
        onVoiceCreated('cloned-voice-id', voiceName);
        setIsCreating(false);
        onClose();
        alert('Voice created successfully!');
      }, 2000);
    } catch (error) {
      console.error('Error creating voice:', error);
      alert('Failed to create voice. Please try again.');
      setIsCreating(false);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Voice Cloning</h2>
            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors duration-200"
            >
              <Trash2 className="h-5 w-5 text-gray-500" />
            </button>
          </div>

          <div className="space-y-6">
            {/* Warning */}
            <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4">
              <div className="flex items-start">
                <AlertCircle className="h-5 w-5 text-yellow-600 dark:text-yellow-400 mt-0.5 mr-3" />
                <div>
                  <h3 className="font-medium text-yellow-800 dark:text-yellow-200">Voice Cloning Guidelines</h3>
                  <p className="text-sm text-yellow-700 dark:text-yellow-300 mt-1">
                    Only clone voices you have permission to use. Record at least 30 seconds of clear speech for best results.
                  </p>
                </div>
              </div>
            </div>

            {/* Voice Details */}
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Voice Name *
                </label>
                <input
                  type="text"
                  value={voiceName}
                  onChange={(e) => setVoiceName(e.target.value)}
                  placeholder="Enter a name for your voice"
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Description (Optional)
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Describe the voice characteristics"
                  rows={3}
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white resize-none"
                />
              </div>
            </div>

            {/* Recording Section */}
            <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-6">
              <h3 className="font-semibold text-gray-900 dark:text-white mb-4">Voice Recording</h3>
              
              <div className="text-center">
                {!audioBlob ? (
                  <div>
                    <button
                      onClick={isRecording ? stopRecording : startRecording}
                      className={`inline-flex items-center px-6 py-3 rounded-full font-medium transition-all duration-300 ${
                        isRecording
                          ? 'bg-red-600 hover:bg-red-700 text-white animate-pulse'
                          : 'bg-purple-600 hover:bg-purple-700 text-white'
                      }`}
                    >
                      {isRecording ? (
                        <>
                          <MicOff className="mr-2 h-5 w-5" />
                          Stop Recording ({formatTime(recordingTime)})
                        </>
                      ) : (
                        <>
                          <Mic className="mr-2 h-5 w-5" />
                          Start Recording
                        </>
                      )}
                    </button>
                    
                    {isRecording && (
                      <div className="mt-4">
                        <div className="flex justify-center items-center space-x-1">
                          {[...Array(5)].map((_, i) => (
                            <div
                              key={i}
                              className="bg-red-500 rounded-full animate-pulse"
                              style={{
                                width: '8px',
                                height: `${Math.random() * 30 + 10}px`,
                                animationDelay: `${i * 0.1}s`
                              }}
                            />
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div>
                    <div className="flex justify-center space-x-4 mb-4">
                      <button
                        onClick={playRecording}
                        className="flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors duration-200"
                      >
                        <Play className="mr-2 h-4 w-4" />
                        Play Recording
                      </button>
                      
                      <button
                        onClick={clearRecording}
                        className="flex items-center px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg transition-colors duration-200"
                      >
                        <Trash2 className="mr-2 h-4 w-4" />
                        Clear
                      </button>
                    </div>
                    
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Recording duration: {formatTime(recordingTime)}
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* File Upload Alternative */}
            <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6">
              <div className="text-center">
                <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <p className="text-gray-600 dark:text-gray-300 mb-2">
                  Or upload an audio file
                </p>
                <input
                  type="file"
                  accept="audio/*"
                  className="hidden"
                  id="audio-upload"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      setAudioBlob(file);
                    }
                  }}
                />
                <label
                  htmlFor="audio-upload"
                  className="cursor-pointer text-purple-600 hover:text-purple-700 font-medium"
                >
                  Choose audio file
                </label>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                  Supports MP3, WAV, M4A (max 10MB)
                </p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex justify-end space-x-4 pt-4 border-t border-gray-200 dark:border-gray-600">
              <button
                onClick={onClose}
                className="px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200 transition-colors duration-200"
              >
                Cancel
              </button>
              
              <button
                onClick={createVoice}
                disabled={!audioBlob || !voiceName.trim() || isCreating}
                className="flex items-center px-6 py-2 bg-purple-600 hover:bg-purple-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white rounded-lg font-medium transition-colors duration-200"
              >
                {isCreating ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Creating Voice...
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    Create Voice
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>

      <audio ref={audioRef} className="hidden" />
    </div>
  );
};
import React from 'react';
import { Play, Pause, Square, Download, SkipBack, SkipForward, Volume2 } from 'lucide-react';
import { AudioState } from '../types';
import { formatDuration } from '../utils/fileUtils';

interface AudioControlsProps {
  audioState: AudioState;
  onPlay: () => void;
  onPause: () => void;
  onStop: () => void;
  onSeek: (time: number) => void;
  onVolumeChange: (volume: number) => void;
  onSpeedChange: (speed: number) => void;
  onDownload: () => void;
  volume: number;
  playbackSpeed: number;
}

export const AudioControls: React.FC<AudioControlsProps> = ({
  audioState,
  onPlay,
  onPause,
  onStop,
  onSeek,
  onVolumeChange,
  onSpeedChange,
  onDownload,
  volume,
  playbackSpeed
}) => {
  const { isPlaying, currentTime, duration, isLoading } = audioState;

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = parseFloat(e.target.value);
    onSeek(time);
  };

  const speedOptions = [0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0];

  return (
    <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-6 transition-colors duration-300">
      <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-6 flex items-center">
        <Volume2 className="mr-2 h-5 w-5 text-purple-600" />
        Audio Controls
      </h2>

      {/* Waveform/Progress Bar */}
      <div className="mb-6">
        <div className="relative">
          <input
            type="range"
            min="0"
            max={duration || 100}
            value={currentTime}
            onChange={handleSeek}
            disabled={!duration || isLoading}
            className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
          />
          <div 
            className="absolute top-0 left-0 h-2 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg pointer-events-none"
            style={{ width: `${duration ? (currentTime / duration) * 100 : 0}%` }}
          />
        </div>
        <div className="flex justify-between text-sm text-gray-500 dark:text-gray-400 mt-2">
          <span>{formatDuration(currentTime)}</span>
          <span>{formatDuration(duration)}</span>
        </div>
      </div>

      {/* Main Controls */}
      <div className="flex items-center justify-center space-x-4 mb-6">
        <button
          onClick={() => onSeek(Math.max(0, currentTime - 10))}
          disabled={!duration || isLoading}
          className="p-3 rounded-full bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200"
          aria-label="Rewind 10 seconds"
        >
          <SkipBack className="h-5 w-5 text-gray-700 dark:text-gray-300" />
        </button>

        <button
          onClick={isPlaying ? onPause : onPlay}
          disabled={!duration || isLoading}
          className="p-4 rounded-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 disabled:opacity-50 disabled:cursor-not-allowed text-white shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
          aria-label={isPlaying ? 'Pause' : 'Play'}
        >
          {isLoading ? (
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white"></div>
          ) : isPlaying ? (
            <Pause className="h-6 w-6" />
          ) : (
            <Play className="h-6 w-6 ml-1" />
          )}
        </button>

        <button
          onClick={onStop}
          disabled={!duration || isLoading}
          className="p-3 rounded-full bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200"
          aria-label="Stop"
        >
          <Square className="h-5 w-5 text-gray-700 dark:text-gray-300" />
        </button>

        <button
          onClick={() => onSeek(Math.min(duration, currentTime + 10))}
          disabled={!duration || isLoading}
          className="p-3 rounded-full bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200"
          aria-label="Forward 10 seconds"
        >
          <SkipForward className="h-5 w-5 text-gray-700 dark:text-gray-300" />
        </button>
      </div>

      {/* Advanced Controls */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Volume Control */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
            Volume: {Math.round(volume * 100)}%
          </label>
          <input
            type="range"
            min="0"
            max="1"
            step="0.1"
            value={volume}
            onChange={(e) => onVolumeChange(parseFloat(e.target.value))}
            className="w-full"
          />
        </div>

        {/* Speed Control */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
            Speed: {playbackSpeed}x
          </label>
          <select
            value={playbackSpeed}
            onChange={(e) => onSpeedChange(parseFloat(e.target.value))}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
          >
            {speedOptions.map(speed => (
              <option key={speed} value={speed}>
                {speed}x
              </option>
            ))}
          </select>
        </div>

        {/* Download Button */}
        <div className="flex items-end">
          <button
            onClick={onDownload}
            disabled={!duration || isLoading}
            className="w-full flex items-center justify-center px-4 py-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white rounded-lg font-medium transition-colors duration-200"
          >
            <Download className="mr-2 h-4 w-4" />
            Download MP3
          </button>
        </div>
      </div>

      {/* Audio Visualization */}
      {isPlaying && (
        <div className="mt-6 flex justify-center items-center space-x-1">
          {[...Array(12)].map((_, i) => (
            <div
              key={i}
              className="bg-gradient-to-t from-purple-600 to-blue-600 rounded-full animate-pulse"
              style={{
                width: '4px',
                height: `${Math.random() * 30 + 10}px`,
                animationDelay: `${i * 0.1}s`,
                animationDuration: `${Math.random() * 0.5 + 0.5}s`
              }}
            />
          ))}
        </div>
      )}
    </div>
  );
};
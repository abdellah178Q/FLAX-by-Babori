import React, { useState, useEffect } from 'react';
import { User, Play, Pause, Volume2, Settings, Star } from 'lucide-react';
import { Voice } from '../types';
import { ElevenLabsService } from '../services/elevenLabsService';

interface VoiceSelectorProps {
  selectedVoice: Voice | null;
  onVoiceSelect: (voice: Voice) => void;
  voiceSettings: any;
  onSettingsChange: (settings: any) => void;
}

export const VoiceSelector: React.FC<VoiceSelectorProps> = ({
  selectedVoice,
  onVoiceSelect,
  voiceSettings,
  onSettingsChange
}) => {
  const [voices, setVoices] = useState<Voice[]>([]);
  const [loading, setLoading] = useState(true);
  const [previewingVoice, setPreviewingVoice] = useState<string | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  useEffect(() => {
    loadVoices();
  }, []);

  const loadVoices = async () => {
    try {
      const voiceData = await ElevenLabsService.getVoices();
      setVoices(voiceData);
      if (voiceData.length > 0 && !selectedVoice) {
        onVoiceSelect(voiceData[0]);
      }
    } catch (error) {
      console.error('Failed to load voices:', error);
    } finally {
      setLoading(false);
    }
  };

  const previewVoice = async (voice: Voice) => {
    if (previewingVoice === voice.voice_id) {
      setPreviewingVoice(null);
      return;
    }

    setPreviewingVoice(voice.voice_id);
    
    try {
      const audioBlob = await ElevenLabsService.generateSpeech(
        "Hello, this is a preview of my voice. I can help you convert your text to natural speech.",
        voice.voice_id,
        voiceSettings
      );
      
      const audio = new Audio(URL.createObjectURL(audioBlob));
      audio.play();
      audio.onended = () => setPreviewingVoice(null);
    } catch (error) {
      console.error('Failed to preview voice:', error);
      setPreviewingVoice(null);
    }
  };

  const filteredVoices = voices.filter(voice => {
    const matchesSearch = voice.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         voice.labels.description?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || voice.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const categories = [
    { id: 'all', name: 'All Voices' },
    { id: 'premade', name: 'Premade' },
    { id: 'professional', name: 'Professional' },
    { id: 'cloned', name: 'Cloned' }
  ];

  if (loading) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-6 transition-colors duration-300">
        <div className="animate-pulse">
          <div className="h-6 bg-gray-300 dark:bg-gray-600 rounded mb-4"></div>
          <div className="space-y-3">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-16 bg-gray-300 dark:bg-gray-600 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-6 transition-colors duration-300">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-gray-900 dark:text-white flex items-center">
          <User className="mr-2 h-5 w-5 text-purple-600" />
          Voice Selection
        </h2>
        <button
          onClick={() => setShowSettings(!showSettings)}
          className="p-2 rounded-lg bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors duration-200"
        >
          <Settings className="h-4 w-4 text-gray-600 dark:text-gray-300" />
        </button>
      </div>

      {/* Search and Filter */}
      <div className="mb-4 space-y-3">
        <input
          type="text"
          placeholder="Search voices..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
        />
        
        <div className="flex flex-wrap gap-2">
          {categories.map(category => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`px-3 py-1 rounded-full text-sm font-medium transition-colors duration-200 ${
                selectedCategory === category.id
                  ? 'bg-purple-600 text-white'
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
              }`}
            >
              {category.name}
            </button>
          ))}
        </div>
      </div>

      {/* Voice Settings Panel */}
      {showSettings && (
        <div className="mb-6 p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
          <h3 className="text-sm font-semibold text-gray-900 dark:text-white mb-3">Voice Settings</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                Stability: {voiceSettings.stability.toFixed(2)}
              </label>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={voiceSettings.stability}
                onChange={(e) => onSettingsChange({
                  ...voiceSettings,
                  stability: parseFloat(e.target.value)
                })}
                className="w-full"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                Similarity: {voiceSettings.similarity_boost.toFixed(2)}
              </label>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={voiceSettings.similarity_boost}
                onChange={(e) => onSettingsChange({
                  ...voiceSettings,
                  similarity_boost: parseFloat(e.target.value)
                })}
                className="w-full"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                Style: {voiceSettings.style.toFixed(2)}
              </label>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={voiceSettings.style}
                onChange={(e) => onSettingsChange({
                  ...voiceSettings,
                  style: parseFloat(e.target.value)
                })}
                className="w-full"
              />
            </div>
            <div className="flex items-center">
              <input
                type="checkbox"
                id="speaker-boost"
                checked={voiceSettings.use_speaker_boost}
                onChange={(e) => onSettingsChange({
                  ...voiceSettings,
                  use_speaker_boost: e.target.checked
                })}
                className="mr-2"
              />
              <label htmlFor="speaker-boost" className="text-xs font-medium text-gray-700 dark:text-gray-300">
                Speaker Boost
              </label>
            </div>
          </div>
        </div>
      )}

      {/* Voice List */}
      <div className="space-y-3 max-h-96 overflow-y-auto">
        {filteredVoices.map((voice) => (
          <div
            key={voice.voice_id}
            className={`p-4 rounded-lg border-2 cursor-pointer transition-all duration-300 ${
              selectedVoice?.voice_id === voice.voice_id
                ? 'border-purple-500 bg-purple-50 dark:bg-purple-900/20'
                : 'border-gray-200 dark:border-gray-600 hover:border-purple-300 dark:hover:border-purple-500'
            }`}
            onClick={() => onVoiceSelect(voice)}
          >
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <div className="flex items-center">
                  <h3 className="font-semibold text-gray-900 dark:text-white">{voice.name}</h3>
                  {voice.category === 'professional' && (
                    <Star className="ml-2 h-4 w-4 text-yellow-500" />
                  )}
                </div>
                <div className="flex flex-wrap gap-2 mt-1">
                  {voice.labels.gender && (
                    <span className="text-xs bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 px-2 py-1 rounded">
                      {voice.labels.gender}
                    </span>
                  )}
                  {voice.labels.accent && (
                    <span className="text-xs bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 px-2 py-1 rounded">
                      {voice.labels.accent}
                    </span>
                  )}
                  {voice.labels.age && (
                    <span className="text-xs bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-200 px-2 py-1 rounded">
                      {voice.labels.age}
                    </span>
                  )}
                </div>
                {voice.labels.description && (
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                    {voice.labels.description}
                  </p>
                )}
              </div>
              
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  previewVoice(voice);
                }}
                className="ml-3 p-2 rounded-lg bg-purple-100 dark:bg-purple-900 hover:bg-purple-200 dark:hover:bg-purple-800 transition-colors duration-200"
                disabled={previewingVoice === voice.voice_id}
              >
                {previewingVoice === voice.voice_id ? (
                  <Pause className="h-4 w-4 text-purple-600" />
                ) : (
                  <Play className="h-4 w-4 text-purple-600" />
                )}
              </button>
            </div>
          </div>
        ))}
      </div>

      {filteredVoices.length === 0 && (
        <div className="text-center py-8">
          <Volume2 className="h-12 w-12 text-gray-400 mx-auto mb-3" />
          <p className="text-gray-500 dark:text-gray-400">No voices found matching your search.</p>
        </div>
      )}
    </div>
  );
};
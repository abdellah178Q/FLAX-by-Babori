import React, { useState } from 'react';
import { Settings, Sliders, Zap, Brain, Volume2, X } from 'lucide-react';

interface AdvancedSettingsProps {
  isOpen: boolean;
  onClose: () => void;
  voiceSettings: any;
  onSettingsChange: (settings: any) => void;
}

export const AdvancedSettings: React.FC<AdvancedSettingsProps> = ({
  isOpen,
  onClose,
  voiceSettings,
  onSettingsChange
}) => {
  const [activeTab, setActiveTab] = useState('voice');

  if (!isOpen) return null;

  const updateSetting = (key: string, value: any) => {
    onSettingsChange({
      ...voiceSettings,
      [key]: value
    });
  };

  const presets = [
    {
      name: 'Natural',
      description: 'Balanced and natural sounding',
      settings: { stability: 0.5, similarity_boost: 0.75, style: 0.0 }
    },
    {
      name: 'Expressive',
      description: 'More emotional and dynamic',
      settings: { stability: 0.3, similarity_boost: 0.8, style: 0.4 }
    },
    {
      name: 'Stable',
      description: 'Consistent and clear',
      settings: { stability: 0.8, similarity_boost: 0.6, style: 0.1 }
    },
    {
      name: 'Creative',
      description: 'Varied and artistic',
      settings: { stability: 0.2, similarity_boost: 0.9, style: 0.6 }
    }
  ];

  const applyPreset = (preset: any) => {
    onSettingsChange({
      ...voiceSettings,
      ...preset.settings
    });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center">
            <Settings className="mr-2 h-6 w-6 text-purple-600" />
            Advanced Voice Settings
          </h2>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors duration-200"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-200 dark:border-gray-700">
          {[
            { id: 'voice', label: 'Voice Control', icon: Volume2 },
            { id: 'presets', label: 'Presets', icon: Zap },
            { id: 'advanced', label: 'Advanced', icon: Brain }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center px-6 py-3 font-medium transition-colors duration-200 ${
                activeTab === tab.id
                  ? 'text-purple-600 border-b-2 border-purple-600'
                  : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200'
              }`}
            >
              <tab.icon className="mr-2 h-4 w-4" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-96">
          {activeTab === 'voice' && (
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                  Stability: {voiceSettings.stability.toFixed(2)}
                </label>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.01"
                  value={voiceSettings.stability}
                  onChange={(e) => updateSetting('stability', parseFloat(e.target.value))}
                  className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
                />
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                  Higher values make the voice more consistent but less expressive
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                  Similarity Boost: {voiceSettings.similarity_boost.toFixed(2)}
                </label>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.01"
                  value={voiceSettings.similarity_boost}
                  onChange={(e) => updateSetting('similarity_boost', parseFloat(e.target.value))}
                  className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
                />
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                  Enhances similarity to the original voice
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                  Style Exaggeration: {voiceSettings.style.toFixed(2)}
                </label>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.01"
                  value={voiceSettings.style}
                  onChange={(e) => updateSetting('style', parseFloat(e.target.value))}
                  className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
                />
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                  Amplifies the style of the original speaker
                </p>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Speaker Boost
                  </label>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Boost similarity to speaker and reduce background noise
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={voiceSettings.use_speaker_boost}
                  onChange={(e) => updateSetting('use_speaker_boost', e.target.checked)}
                  className="w-4 h-4 text-purple-600 bg-gray-100 border-gray-300 rounded focus:ring-purple-500"
                />
              </div>
            </div>
          )}

          {activeTab === 'presets' && (
            <div className="space-y-4">
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                Quick presets to optimize voice settings for different use cases
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {presets.map((preset) => (
                  <div
                    key={preset.name}
                    className="border border-gray-200 dark:border-gray-600 rounded-lg p-4 hover:border-purple-500 transition-colors duration-200 cursor-pointer"
                    onClick={() => applyPreset(preset)}
                  >
                    <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
                      {preset.name}
                    </h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                      {preset.description}
                    </p>
                    <div className="text-xs text-gray-500 dark:text-gray-400 space-y-1">
                      <div>Stability: {preset.settings.stability}</div>
                      <div>Similarity: {preset.settings.similarity_boost}</div>
                      <div>Style: {preset.settings.style}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'advanced' && (
            <div className="space-y-6">
              <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
                <h3 className="font-medium text-blue-900 dark:text-blue-100 mb-2">
                  Model Selection
                </h3>
                <select
                  value="eleven_multilingual_v2"
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                >
                  <option value="eleven_multilingual_v2">Multilingual v2 (Recommended)</option>
                  <option value="eleven_monolingual_v1">Monolingual v1</option>
                  <option value="eleven_multilingual_v1">Multilingual v1</option>
                </select>
                <p className="text-xs text-blue-800 dark:text-blue-200 mt-1">
                  Different models optimized for various languages and use cases
                </p>
              </div>

              <div className="bg-yellow-50 dark:bg-yellow-900/20 rounded-lg p-4">
                <h3 className="font-medium text-yellow-900 dark:text-yellow-100 mb-2">
                  Output Format
                </h3>
                <select
                  value="mp3_44100_128"
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                >
                  <option value="mp3_44100_128">MP3 - 44.1kHz, 128kbps</option>
                  <option value="mp3_44100_192">MP3 - 44.1kHz, 192kbps</option>
                  <option value="pcm_16000">PCM - 16kHz</option>
                  <option value="pcm_22050">PCM - 22.05kHz</option>
                  <option value="pcm_24000">PCM - 24kHz</option>
                  <option value="pcm_44100">PCM - 44.1kHz</option>
                </select>
                <p className="text-xs text-yellow-800 dark:text-yellow-200 mt-1">
                  Higher quality formats result in larger file sizes
                </p>
              </div>

              <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4">
                <h3 className="font-medium text-green-900 dark:text-green-100 mb-2">
                  Performance Settings
                </h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-green-800 dark:text-green-200">
                      Optimize for latency
                    </span>
                    <input
                      type="checkbox"
                      className="w-4 h-4 text-purple-600 bg-gray-100 border-gray-300 rounded focus:ring-purple-500"
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-green-800 dark:text-green-200">
                      Enable streaming
                    </span>
                    <input
                      type="checkbox"
                      className="w-4 h-4 text-purple-600 bg-gray-100 border-gray-300 rounded focus:ring-purple-500"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700 rounded-b-2xl">
          <div className="flex justify-between items-center">
            <button
              onClick={() => {
                onSettingsChange({
                  stability: 0.5,
                  similarity_boost: 0.75,
                  style: 0.0,
                  use_speaker_boost: true
                });
              }}
              className="text-sm text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200 transition-colors duration-200"
            >
              Reset to Defaults
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-medium transition-colors duration-200"
            >
              Apply Settings
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
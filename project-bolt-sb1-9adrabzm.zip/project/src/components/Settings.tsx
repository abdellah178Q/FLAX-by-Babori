import React from 'react';
import { X, Palette, Accessibility, Globe, Shield } from 'lucide-react';
import { AppSettings } from '../types';

interface SettingsProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onSettingsChange: (settings: AppSettings) => void;
}

export const Settings: React.FC<SettingsProps> = ({
  isOpen,
  onClose,
  settings,
  onSettingsChange
}) => {
  if (!isOpen) return null;

  const updateSetting = (key: string, value: any) => {
    onSettingsChange({
      ...settings,
      [key]: value
    });
  };

  const updateTheme = (key: string, value: any) => {
    onSettingsChange({
      ...settings,
      theme: {
        ...settings.theme,
        [key]: value
      }
    });
  };

  const updateAccessibility = (key: string, value: any) => {
    onSettingsChange({
      ...settings,
      theme: {
        ...settings.theme,
        accessibility: {
          ...settings.theme.accessibility,
          [key]: value
        }
      }
    });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Settings</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors duration-200"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        <div className="p-6 space-y-8">
          {/* Appearance */}
          <section>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
              <Palette className="mr-2 h-5 w-5 text-purple-600" />
              Appearance
            </h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Theme
                </label>
                <div className="flex space-x-3">
                  <button
                    onClick={() => updateTheme('mode', 'light')}
                    className={`px-4 py-2 rounded-lg border-2 transition-colors duration-200 ${
                      settings.theme.mode === 'light'
                        ? 'border-purple-500 bg-purple-50 text-purple-700'
                        : 'border-gray-300 hover:border-gray-400'
                    }`}
                  >
                    Light
                  </button>
                  <button
                    onClick={() => updateTheme('mode', 'dark')}
                    className={`px-4 py-2 rounded-lg border-2 transition-colors duration-200 ${
                      settings.theme.mode === 'dark'
                        ? 'border-purple-500 bg-purple-50 dark:bg-purple-900 text-purple-700 dark:text-purple-300'
                        : 'border-gray-300 dark:border-gray-600 hover:border-gray-400'
                    }`}
                  >
                    Dark
                  </button>
                </div>
              </div>
            </div>
          </section>

          {/* Accessibility */}
          <section>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
              <Accessibility className="mr-2 h-5 w-5 text-purple-600" />
              Accessibility
            </h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    High Contrast Mode
                  </label>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Increases contrast for better visibility
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={settings.theme.accessibility.highContrast}
                  onChange={(e) => updateAccessibility('highContrast', e.target.checked)}
                  className="w-4 h-4 text-purple-600 bg-gray-100 border-gray-300 rounded focus:ring-purple-500 dark:focus:ring-purple-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Large Text
                  </label>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Increases font size throughout the app
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={settings.theme.accessibility.largeText}
                  onChange={(e) => updateAccessibility('largeText', e.target.checked)}
                  className="w-4 h-4 text-purple-600 bg-gray-100 border-gray-300 rounded focus:ring-purple-500 dark:focus:ring-purple-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Dyslexia-Friendly Font
                  </label>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Uses OpenDyslexic font for better reading
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={settings.theme.accessibility.dyslexiaFriendly}
                  onChange={(e) => updateAccessibility('dyslexiaFriendly', e.target.checked)}
                  className="w-4 h-4 text-purple-600 bg-gray-100 border-gray-300 rounded focus:ring-purple-500 dark:focus:ring-purple-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                />
              </div>
            </div>
          </section>

          {/* Audio Settings */}
          <section>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
              <Globe className="mr-2 h-5 w-5 text-purple-600" />
              Audio Preferences
            </h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Auto-play Generated Speech
                  </label>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Automatically play audio when generation completes
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={settings.autoPlay}
                  onChange={(e) => updateSetting('autoPlay', e.target.checked)}
                  className="w-4 h-4 text-purple-600 bg-gray-100 border-gray-300 rounded focus:ring-purple-500 dark:focus:ring-purple-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Highlight Text During Playback
                  </label>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Show visual indication of spoken words
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={settings.highlightText}
                  onChange={(e) => updateSetting('highlightText', e.target.checked)}
                  className="w-4 h-4 text-purple-600 bg-gray-100 border-gray-300 rounded focus:ring-purple-500 dark:focus:ring-purple-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Default Speech Rate: {settings.speechRate.toFixed(1)}x
                </label>
                <input
                  type="range"
                  min="0.5"
                  max="2.0"
                  step="0.1"
                  value={settings.speechRate}
                  onChange={(e) => updateSetting('speechRate', parseFloat(e.target.value))}
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Default Volume: {Math.round(settings.volume * 100)}%
                </label>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={settings.volume}
                  onChange={(e) => updateSetting('volume', parseFloat(e.target.value))}
                  className="w-full"
                />
              </div>
            </div>
          </section>

          {/* Privacy & Security */}
          <section>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
              <Shield className="mr-2 h-5 w-5 text-purple-600" />
              Privacy & Security
            </h3>
            <div className="space-y-4">
              <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-2">Data Processing</h4>
                <p className="text-sm text-blue-800 dark:text-blue-200">
                  Your text is processed by ElevenLabs AI to generate speech. Text is not stored permanently and is only used for audio generation.
                </p>
              </div>
              
              <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                <h4 className="font-medium text-green-900 dark:text-green-100 mb-2">Secure Connection</h4>
                <p className="text-sm text-green-800 dark:text-green-200">
                  All communications with AI services are encrypted and secure.
                </p>
              </div>
            </div>
          </section>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700 rounded-b-2xl">
          <div className="flex justify-end">
            <button
              onClick={onClose}
              className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-medium transition-colors duration-200"
            >
              Save Settings
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
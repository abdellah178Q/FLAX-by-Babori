import React, { useState, useCallback } from 'react';
import { Upload, FileText, Image, Mic, X, Check } from 'lucide-react';
import { readTextFile, validateTextInput, supportedFileTypes } from '../utils/fileUtils';

interface TextInputProps {
  text: string;
  setText: (text: string) => void;
  onGenerate: () => void;
  isGenerating: boolean;
}

export const TextInput: React.FC<TextInputProps> = ({
  text,
  setText,
  onGenerate,
  isGenerating
}) => {
  const [dragActive, setDragActive] = useState(false);
  const [fileName, setFileName] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback(async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      await handleFileUpload(files[0]);
    }
  }, []);

  const handleFileUpload = async (file: File) => {
    setError(null);
    
    try {
      if (file.type.startsWith('text/') || file.name.endsWith('.txt') || file.name.endsWith('.md')) {
        const fileText = await readTextFile(file);
        const validation = validateTextInput(fileText);
        
        if (validation.isValid) {
          setText(fileText);
          setFileName(file.name);
        } else {
          setError(validation.error || 'Invalid text file');
        }
      } else {
        setError('Unsupported file type. Please upload a text file.');
      }
    } catch (err) {
      setError('Failed to read file. Please try again.');
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFileUpload(files[0]);
    }
  };

  const clearText = () => {
    setText('');
    setFileName(null);
    setError(null);
  };

  const validation = validateTextInput(text);
  const canGenerate = validation.isValid && !isGenerating;

  return (
    <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-6 transition-colors duration-300">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold text-gray-900 dark:text-white flex items-center">
          <FileText className="mr-2 h-5 w-5 text-purple-600" />
          Text Input
        </h2>
        {text && (
          <button
            onClick={clearText}
            className="text-gray-400 hover:text-red-500 transition-colors duration-200"
            aria-label="Clear text"
          >
            <X className="h-5 w-5" />
          </button>
        )}
      </div>

      {/* File Upload Area */}
      <div
        className={`border-2 border-dashed rounded-xl p-6 mb-4 transition-all duration-300 ${
          dragActive
            ? 'border-purple-500 bg-purple-50 dark:bg-purple-900/20'
            : 'border-gray-300 dark:border-gray-600 hover:border-purple-400 dark:hover:border-purple-500'
        }`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
      >
        <div className="text-center">
          <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
          <p className="text-gray-600 dark:text-gray-300 mb-2">
            Drag and drop a text file here, or{' '}
            <label className="text-purple-600 hover:text-purple-700 cursor-pointer font-medium">
              browse
              <input
                type="file"
                className="hidden"
                accept=".txt,.md,.rtf"
                onChange={handleFileInputChange}
              />
            </label>
          </p>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Supports: {supportedFileTypes.map(type => type.extension).join(', ')}
          </p>
          {fileName && (
            <div className="mt-3 flex items-center justify-center">
              <Check className="h-4 w-4 text-green-500 mr-2" />
              <span className="text-sm text-green-600 dark:text-green-400">{fileName}</span>
            </div>
          )}
        </div>
      </div>

      {/* Text Area */}
      <div className="mb-4">
        <label htmlFor="text-input" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          Enter your text (max 5,000 characters)
        </label>
        <textarea
          id="text-input"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Type or paste your text here..."
          className="w-full h-48 px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none bg-white dark:bg-gray-700 text-gray-900 dark:text-white transition-colors duration-300"
          maxLength={5000}
        />
        <div className="flex justify-between items-center mt-2">
          <span className="text-sm text-gray-500 dark:text-gray-400">
            {text.length}/5,000 characters
          </span>
          {error && (
            <span className="text-sm text-red-500">{error}</span>
          )}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="flex flex-wrap gap-3 mb-6">
        <button
          className="flex items-center px-3 py-2 bg-gray-100 dark:bg-gray-700 rounded-lg text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors duration-200"
          onClick={() => setText('Welcome to FLAX by Babori! This is a powerful text-to-speech application that converts your text into natural-sounding speech using advanced AI technology.')}
        >
          <FileText className="mr-2 h-4 w-4" />
          Sample Text
        </button>
        
        <button
          className="flex items-center px-3 py-2 bg-gray-100 dark:bg-gray-700 rounded-lg text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors duration-200"
          disabled
        >
          <Image className="mr-2 h-4 w-4" />
          OCR (Coming Soon)
        </button>
        
        <button
          className="flex items-center px-3 py-2 bg-gray-100 dark:bg-gray-700 rounded-lg text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors duration-200"
          disabled
        >
          <Mic className="mr-2 h-4 w-4" />
          Voice Input (Coming Soon)
        </button>
      </div>

      {/* Generate Button */}
      <button
        onClick={onGenerate}
        disabled={!canGenerate}
        className={`w-full py-3 px-6 rounded-xl font-semibold text-white transition-all duration-300 ${
          canGenerate
            ? 'bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5'
            : 'bg-gray-400 dark:bg-gray-600 cursor-not-allowed'
        }`}
      >
        {isGenerating ? (
          <span className="flex items-center justify-center">
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
            Generating Speech...
          </span>
        ) : (
          'Generate Speech'
        )}
      </button>
    </div>
  );
};
export const readTextFile = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      resolve(event.target?.result as string);
    };
    reader.onerror = () => {
      reject(new Error('Failed to read file'));
    };
    reader.readAsText(file);
  });
};

export const downloadAudio = (audioBlob: Blob, filename: string = 'speech.mp3') => {
  const url = URL.createObjectURL(audioBlob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};

export const formatDuration = (seconds: number): string => {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, '0')}`;
};

export const validateTextInput = (text: string): { isValid: boolean; error?: string } => {
  if (!text.trim()) {
    return { isValid: false, error: 'Text cannot be empty' };
  }
  
  if (text.length > 5000) {
    return { isValid: false, error: 'Text exceeds maximum length of 5000 characters' };
  }
  
  return { isValid: true };
};

export const extractTextFromPDF = async (file: File): Promise<string> => {
  // This would typically require a PDF parsing library
  // For now, return a placeholder implementation
  return new Promise((resolve) => {
    resolve('PDF text extraction would be implemented here with a proper PDF parser library.');
  });
};

export const supportedFileTypes = [
  { extension: '.txt', mimeType: 'text/plain', description: 'Text files' },
  { extension: '.md', mimeType: 'text/markdown', description: 'Markdown files' },
  { extension: '.rtf', mimeType: 'application/rtf', description: 'Rich Text Format' }
];